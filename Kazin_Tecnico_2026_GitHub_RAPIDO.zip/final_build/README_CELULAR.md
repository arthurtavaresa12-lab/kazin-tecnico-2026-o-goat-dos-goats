# Kazin Técnico 2026 — aplicativo Android

Este projeto transforma a versão V30 do jogo em um aplicativo Android usando WebView.

## Gerar pelo celular
1. Crie um repositório público no GitHub.
2. Envie **o conteúdo desta pasta** para a raiz do repositório (não envie o ZIP dentro do repositório).
3. Abra **Actions** e execute **Gerar aplicativo Kazin Tecnico 2026**.
4. Quando terminar, abra a execução e baixe o artefato **Kazin-Tecnico-2026-APK**.

O projeto usa Android 16 / API 36 e gera também um AAB para publicação na Google Play.
O AAB de release ainda precisa ser assinado com uma chave de publicação antes de enviar à Play Store.
